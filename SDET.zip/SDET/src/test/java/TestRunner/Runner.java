package TestRunner;
				
@cucumber.api.CucumberOptions(features="resources/CucumberProject",
tags= {"@testLogin"},
glue={"StepDefinitions"})	

public class Runner {
    
}
