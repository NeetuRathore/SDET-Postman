package TestRunner;

import org.testng.annotations.Test;

import LamdaTestNG2.AppTest;
import cucumber.api.CucumberOptions;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;


@CucumberOptions(features="resources/CucumberProject",
tags= {"@testLogin"},
glue={"StepDefinitions"})

public class NewTestRunner extends AbstractTestNGCucumberTests{
	
	public void f() {
		System.out.println("Hello");
		 AppTest.setUpBrowser();
	}
	
  @BeforeClass
  public void beforeClass() {
	  System.out.println("Hello");
	  //AppTest.setUpBrowser();
  }

  @AfterClass
  public void afterClass() {
	 // AppTest.quitBrowser();
  }

}
