package LamdaTestNG2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
//    public AppTest( String testName )
//    {
//        super( testName );
//    }

    /**
     * @return the suite of tests being tested
     */
static //    public static Test suite()
//    {
//        return new TestSuite( AppTest.class );
//    }
//
//    /**
//     * Rigourous Test :-)
//     */
//    public void testApp()
//    {
//        assertTrue( true );
//    }
	
    WebDriver driver;
   // ChromeDriver driver ;
    List<WebElement> osName = driver.findElements(By.cssSelector(".os-name"));
    List<WebElement> dropDown1 = driver.findElements(By.cssSelector(".doc-selector-container"));
    List<WebElement> deviceName = driver.findElements(By.cssSelector(".device-name"));
    WebElement androidDevice =driver.findElement(By.cssSelector("//span[text()='Samsung Galaxy S21']"));
    WebElement pageTitle =driver.findElement(By.xpath("//h1[text()='Capabilities']"));
    WebElement iosDevice =driver.findElement(By.cssSelector("//span[text()='iPhone 12 Pro']"));
    
    public static void setUpBrowser() {
    	System.setProperty("webdriver.chrome.driver", "C:/Users/Dell/Downloads/chromedriver/chromedriver.exe");
    	driver = new ChromeDriver();
    	driver.manage().window().maximize();
    	//driver.get("http://newtours.demoaut.com/");
    }
    
    public static void quitBrowser() {
    	driver.quit();
    }
    
    
    public void launchURL() {
    	String url = "https://www.browserstack.com/automate/capabilities";
    	driver.get(url);
		
	}
    
    
    public boolean verifySelenium_Cap_Page() {
    	return pageTitle.isDisplayed();
	}
    
    public void userSelect_OS_Device(String os, String device) {
    	if(os.equals("Android") && device.equals("Galaxy S21")) {
    		dropDown1.get(0).click();
    		osName.get(1).click();
    		dropDown1.get(2).click();
    		deviceName.get(1).click();
    	}
        
    	if(os.equals("ios") && device.equals("iphone")) {
    		dropDown1.get(0).click();
    		osName.get(0).click();
    		dropDown1.get(2).click();
    		deviceName.get(1).click();
    	}
    	
	}
    
    public boolean verifyResultforAndroid() {
    	return androidDevice.isDisplayed();
    }	
    
    public boolean verifyResultforIos() {
    	return iosDevice.isDisplayed();
    }
}
