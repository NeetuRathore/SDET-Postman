package StepDefinations;

import org.testng.Assert;
import org.testng.annotations.*;

import LamdaTestNG2.AppTest;
import cucumber.api.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login_StepDef{
	AppTest test = new AppTest();
	
	
	@When("^User launch the URL$")	
	public void launchURL() {
		test.launchURL();
	}
	
	@Then("^User navigate to selenium webdriver capabilities page$")
	public void verifySelenium_Cap_Page() {
		Assert.assertEquals(true, test.verifySelenium_Cap_Page());
	}
	
	@When("^user select (.*) and ().*$")
	public void userSelect_OS_Device(String os, String device) {
		test.userSelect_OS_Device(os, device);
	}
	
    @Then("^result is reflected for android on RHS$")
    public void verifyResultforAndroid() {
    	Assert.assertEquals(true, test.verifyResultforAndroid());
    }
    	
    @Then("^result is reflected for ios on RHS$")
    public void verifyResultforIos() {
    	Assert.assertEquals(true, test.verifyResultforIos());
    }

}
